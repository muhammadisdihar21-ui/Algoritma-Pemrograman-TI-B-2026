import myMath

print("Penambahan")
a = int(input("Masukkan Nilai A: "))
b = int(input("Masukkan Nilai B: "))
x = myMath.penambahan(a, b)
print(x)
print()

print("Pengurangan")
a = int(input("Masukkan Nilai A: "))
b = int(input("Masukkan Nilai B: "))
x = myMath.pengurangan(a, b)
print(x)
print()

print("Perkalian")
a = int(input("Masukkan Nilai A: "))
b = int(input("Masukkan Nilai B: "))
x = myMath.perkalian(a, b)
print(x)
print()

print("Pembagian")
a = int(input("Masukkan Nilai A: "))
b = int(input("Masukkan Nilai B: "))
x = myMath.pembagian(a, b)
print(x)
print()

print("Modulus")
a = int(input("Masukkan Nilai A: "))
b = int(input("Masukkan Nilai B: "))
x = myMath.modulus(a, b)
print(x)
print()

print("Fibonacci")
n = int(input("Masukkan Nilai N: "))
x = myMath.fibonacci(n)
print(x)
print()

